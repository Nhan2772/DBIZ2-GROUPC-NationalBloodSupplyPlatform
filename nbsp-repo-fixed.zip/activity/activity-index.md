# Activity Diagram Index: National Blood Supply Chain Platform (NBSP)

One row per use case. Priorities are the effective priorities of W4 v2. Decisions referenced as D-nn are in [decision-log.md](../project/decision-log.md).

## Inputs check

| # | Finding | Status |
|---|---|---|
| 1 | UC-17 was missing from the UC list, the Function List and W5 | Done: W0 UC-17, W1 FR-02-05, W5 |
| 2 | Timed jobs (UC-11, UC-14 overdue, FR-03-05, FR-03-08, UC-17) had no scheduler | Done: NBSP Scheduler in [architecture.md](../architecture/architecture.md) (D-24) |
| 3 | Two numbering schemes for features | Done: F-01 to F-04 only (D-03) |
| 4 | UC-08 decline and failure branches | Done: AD-UC-08 v0.5 (D-04, D-05, D-09) |
| 5 | Actor names differ between documents | Done: one name per role (D-01) |
| 6 | Use case headings in the mid-term report (`UC-8`, `UC14`, `UC 12`) | Open: mid-term report, owner Nhàn |

## Use cases

Rule: draw an activity diagram for a use case that has at least one decision, more than one lane, or a time trigger. A single display step gets "not needed" with a reason.

| Use case | Name | Feature | Priority | Activity diagram | Reason if not needed |
|---|---|---|---|---|---|
| UC-01 | Request Blood Provision | F-01 | Must | `AD-UC-01.md` | |
| UC-02 | View Shipment Details | F-01 | Must | not needed | Read-only display; one lane |
| UC-03 | Confirm Blood Received | F-01 | Must | `AD-UC-03.md` | |
| UC-04 | Record Blood Usage | F-02 | Must | `AD-UC-04.md` | |
| UC-05 | Log Surgical Schedules with Blood Demand | F-03 | Could | `AD-UC-05.md` | |
| UC-06 | Sign in with Hospital account | F-04 | Must | not needed | Same sign-in for every user; other diagrams state it as a precondition |
| UC-07 | View Request Queue | F-01 | Must | not needed | Single display step |
| UC-08 | Approve & Dispatch Blood Order | F-01 | Must | `AD-UC-08.md` | |
| UC-09 | View Inventory Dashboard | F-02 | Should | not needed | Role-scoped display; scope rule is FR-04-03 |
| UC-10 | View Near-Expiry Blood Units | F-02 | Could | not needed | List or empty-list display |
| UC-11 | Receive Below-Threshold Alert | F-02 | Could | `AD-UC-11.md` | |
| UC-12 | Sign in with NBC account | F-04 | Must | not needed | As UC-06 |
| UC-13 | Validate Clinical Demand Data | F-03 | Should | `AD-UC-13.md` | |
| UC-14 | Respond to Data Verification Request | F-03 | Could | `AD-UC-14.md` | |
| UC-15 | Review and Approve Blood Forecast | F-03 | Must | `AD-UC-15.md` | |
| UC-16 | View Validated Blood Forecast | F-03 | Must | not needed | Display step; the no-forecast message is a screen state |
| UC-17 | Synchronise NBC Inventory | F-02 | Must | `AD-UC-17.md` | |

## State catalogue (copy into the data model in DBIZ3; source: D-23)

| Object | States |
|---|---|
| Blood request | Pending, Dispatched, Received, Not approved |
| NBC blood unit (in NBSP) | Available, Reserved |
| Hospital lot | no status (quantity per blood group, product, expiry) |
| Usage record | Used, Discarded |
| Demand record | Flagged, Accepted, Excluded, Pending Verification |
| Verification request | Open, Responded, Overdue |
| Demand period | Open, Finalised |
| Forecast item | Draft, Approved, Rejected |
| Forecast version | Published |
| Alert | Open, Resolved |
| User account | Active, Locked |
