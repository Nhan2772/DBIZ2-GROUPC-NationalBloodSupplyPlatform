# Architecture (analysis level): NBSP

The elements below are the lifelines used in every sequence diagram (decision log D-24).

| Element | Kind | Responsibility |
|---|---|---|
| NBSP Web App | Element | Browser UI for all four actors; shows screens S-F01-01 to S-F04-01 |
| NBSP Backend | Element | Business rules, validation, role and scope checks (FR-04-03), audit (FR-04-04), notifications by in-app badge and email (D-20) |
| NBSP Database | Element | Requests, shipments, hospital lots, usage, demand records, verification requests, forecasts, alerts, accounts, NBC inventory snapshot |
| NBSP Scheduler | Element | Timed jobs: inventory sync (UC-17), verification deadline (FR-03-04), forecast cut-off (FR-03-08), draft forecast generation (FR-03-05) |
| Forecast Model | External | Active deployed model, run by NBSP; trained outside NBSP by the Data/ML team |
| Blood Management Software (BMS) | External system | Source of NBC inventory (read by UC-17); reservation of units (UC-08, D-09) |

```mermaid
flowchart LR
  U["Hospital Staff · Dept · Analyst · Operations"] --> W["NBSP Web App"] --> B["NBSP Backend"]
  S["NBSP Scheduler"] --> B
  B --> D[("NBSP Database")]
  B -->|"read inventory · reserve / release units"| BMS["Blood Management Software"]
  B -->|"run active model"| M["Forecast Model"]
  B -->|"email"| E["Email service"]
```
