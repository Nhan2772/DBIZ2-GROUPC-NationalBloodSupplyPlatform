# Decision Log: NBSP (National Blood Supply Chain Platform)

| Field | Value |
|---|---|
| Version | v1.0 (consolidated from the cross-file consistency review of 18/11/2026) |
| Status | **Proposed**: every row needs team approval before the files in "Impact" are edited |
| Rule | This file is the single source of truth for business decisions. Other documents cite the decision ID (for example "see D-04") instead of writing "decided 2026-11-06" in their own words. A decision changes only by a new row that names what it supersedes. |
| Order of edits after approval | W0, W1 → SD and AD → screen list, screen transition, usage flow, UI conventions → W4, W2, W5, W6 → repo hygiene |

## Summary

| ID | Area | Decision (short) | Supersedes | Approved |
|---|---|---|---|---|
| D-01 | Naming | One actor name per role; "NBC Staff" is retired | Mixed names in W0, W1, SD-07 to SD-12 | |
| D-02 | Naming | One product name, one external-system name, "180+ hospitals" | Brief "about 170"; CVCA "Blood Center Management" | |
| D-03 | Naming | One ID scheme: F-01 to F-04, FR-xx-yy, S-Fxx-nn; legacy FL:F-xx retired | Function list v1 numbering in activity index and W1 trace | |
| D-04 | Ordering | The Dept can mark a request **Not approved** with a mandatory reason | "No not-approved outcome in release 1" (06/11, AD-UC-08 v0.4) | |
| D-05 | Ordering | No partial dispatch; a shortage keeps the request Pending with the reason shown | (confirms 06/11) | |
| D-06 | Ordering | Hospital cancellation is not a function in release 1; handled through D-04 | (new) | |
| D-07 | Ordering | Dispatch selection is suggested earliest-expiry-first (FEFO); the Dept can change it | (new) | |
| D-08 | Ordering | Urgency has three levels: Emergency, Urgent, Routine | BR-01 "agreed list" (undefined) | |
| D-09 | Integration | BMS reservation: one attempt, timeout, idempotency key, compensating release | (new detail of FR-01-03) | |
| D-10 | Receipt | Whole-shipment confirmation only; damaged or missing units are recorded through UC-04 | AD-UC-03 Q2 | |
| D-11 | Shipment | FR-01-04 View shipment details is **Must**; no push notification on dispatch | W4 (Could); AD-UC-08 Q3 confirmed | |
| D-12 | Inventory | Blood product type is a field everywhere; release 1 enables red blood cells only | (new) | |
| D-13 | Inventory | Hospital inventory is kept per lot (blood group, product, expiry date) | AD-UC-04 Q3 open | |
| D-14 | Inventory | Opening hospital inventory: new FR-02-07 (Should); fallback is an onboarding import | (new) | |
| D-15 | Inventory | Sync every 15 min by default (configurable), read-only, stale-data warning on screen | AD-UC-17 Q1, Q3, Q4 | |
| D-16 | Alerts | Below-threshold alerts go to the Dept **and** NBC Operations | AD-UC-11 v0.9 "Dept only"; W0 UC-11 | |
| D-17 | Alerts | One alert per episode (Open until stock recovers); no notification centre | AD-UC-11 Q1; FR-02-04-FE scope | |
| D-18 | Alerts | Release 1 thresholds apply to NBC stock only; hospital-level thresholds are Won't-have | Project brief goal wording | |
| D-19 | Alerts | Thresholds and anomaly-rule values are loaded at deployment and configurable by the NBSP administrator; no screen | (confirms 06/11) | |
| D-20 | Notifications | One notification pattern for NBSP: in-app badge plus email | Open channel in usage flow and screen list | |
| D-21 | Forecasting | Forecast review is per item (Normal / Needs Review, adjust, bulk approve, versioned publication) | AD-UC-15 batch-level approve/reject | |
| D-22 | Forecasting | Verification response options: confirm, correct, supplement; the request can become Overdue | AD-UC-14 v0.2 | |
| D-23 | Data model | One canonical state catalogue (section "State catalogue") | Mixed state names in activity index, AD-UC-14, AD-UC-15 | |
| D-24 | Architecture | One set of sequence-diagram lifelines and an architecture.md with a scheduler | Mixed lifelines in SD-UC-01 to SD-UC-17; activity index finding 2 | |
| D-25 | Scope | Priority changes: FR-01-04 → Must, FR-01-09 → Should, FR-03-01 → Could, FR-02-07 added as Should; justifications rewritten | W4 v1 | |

---

## 1. Naming and identifiers

### D-01 One actor name per role
**Decision.**

| Use this name | Short form | Replaces |
|---|---|---|
| Hospital Staff | Hospital Staff | Hospitals, Receiving Hospitals |
| NBC Blood Storage and Distribution Department | the Dept | NBC Staff, NBC Blood storage & Distribution dept |
| NBC Forecasting Analyst | the Analyst | NBC Analysts, Forecasting Analyst |
| NBC Operations | Operations | Operations (Forecast) side |
| Time (scheduler) | Time | — |
| Blood Management Software | BMS | Blood Center Management (CVCA) |

"NBC users" is the collective term, used only for UC-12 sign-in and FR-04-02.

Actor per use case: UC-09 = Hospital Staff, the Dept, Operations. UC-11 = the Dept, Operations (D-16). UC-12 = the Dept, the Analyst, Operations. UC-17 = Time (primary), BMS (secondary).

**Why.** Five naming variants are in use today; reviewers read them as five actors.

**Impact.** W0 Table 1 and Table 2 (F-02 "NBC Staff"); W1 FR-01-02, FR-01-03, FR-01-08, FR-01-09, FR-02-02, FR-02-03, FR-02-04, FR-04-02; SD-UC-07, 08, 09, 10, 12; use case diagram (UC-11 add Operations); CVCA.

### D-02 Product, system and hospital count
**Decision.** Product: **NBSP, National Blood Supply Chain Platform**. External system: **Blood Management Software (BMS)**. Hospital count: **180+ receiving hospitals**.

**Why.** The CVCA and Context Diagram already say 180+; the brief's "about 170" is the odd one out.

**Impact.** Project brief, W5 title, activity index title, CVCA node "Blood Center Management", README.

### D-03 Identifier scheme
**Decision.** Features F-01 to F-04 (W0 Table 2). Functions FR-<feature>-<nn> (W1). Screens S-F<feature>-<nn>. Activity and sequence diagrams AD-UC-nn and SD-UC-nn. Business rules BR-nn. Decisions D-nn. The legacy function-list numbers (FL:F-01 to F-16) are retired.

**Impact.** Activity index column "Feature"; W1 column "Source trace" (drop FL:F-xx); AD-UC-05 placeholders FR-05-xx → FR-03-01; AD-UC-14 and AD-UC-15 "FL:F-14/15".

---

## 2. Ordering and dispatch (F-01)

### D-04 "Not approved" outcome
**Decision.** The Dept can close a Pending request as **Not approved** with a mandatory reason chosen from a short list (No eligible stock, Request data incorrect, Cancelled by hospital, Other + note). Not approved is a final state. The hospital sees the status and reason on S-F01-02. FR-01-09 stays, effective priority **Should** (D-25).

**Why.**
- Real life: if NBC cannot serve a request, the hospital must know quickly so it can turn to another regional blood centre. A request left Pending forever brings back the phone call that NBSP is meant to remove (project brief, Problem).
- It gives D-05 and D-06 a clean ending at no extra cost.
- The W4 justification ("the Dept has no non-approval path yet") was circular.

**Rejected.** Keep "stays Pending, handle by phone" (06/11). It leaves requests open indefinitely, pollutes the queue (BR-05) and distorts demand data used by forecasting.

**Impact.** AD-UC-08 (add branch, add FR-01-09 to "FRs covered"); SD-UC-08 (keep decline branch, rename actor); W1 FR-01-09 EARS (reason list, final state); usage flow (Dept Flow 1 end state, remove "no not-approved outcome"); screen list modal stays; screen transition Hospital entry "order not approved" (rename from "rejected"); UI conventions OQ-01 closed; activity index state list.

### D-05 No partial dispatch
**Decision.** Confirmed: the selected units must cover the requested quantity. If eligible stock is short, dispatch is blocked, the shortage is shown and the request stays Pending (FR-01-08). The Dept may then wait for stock or use D-04 with reason "No eligible stock". The hospital can submit a new, smaller request.

**Why.** Partial fulfilment needs back-order logic and a split state machine; a new request covers the same need in release 1.

**Impact.** AD-UC-08 node s2 traces to FR-01-08 (not "FR-01-03 proposed").

### D-06 Hospital cancellation
**Decision.** No cancel function in release 1 (added to W0 Won't-have). The hospital phones the Dept, which records D-04 with reason "Cancelled by hospital".

**Why.** Real life needs cancellation (the patient no longer needs the blood), but D-04 already covers it with an audit reason, at zero extra cost.

**Impact.** W0 Table 3 new row.

### D-07 FEFO suggestion for dispatch (BR-09)
**Decision.** New **BR-09**: when the Dept opens a request, NBSP pre-selects eligible units with the earliest expiry date first; the Dept can change the selection. The same rule deducts hospital lots on usage (D-13).

**Why.** First-expiry-first-out is standard blood-bank practice and directly serves the project goal "less blood expires unused". It fits inside the existing L3 FR-01-03-FE and FR-01-03-BE; no new function.

**Impact.** W0 business rules (add BR-09); W1 FR-01-03 EARS; AD-UC-08 s1 text; AD-UC-04 BR-xx → BR-09.

### D-08 Urgency levels
**Decision.** BR-01 urgency list = **Emergency, Urgent, Routine** (UI: Cấp cứu, Khẩn, Thường). The queue is ordered Emergency > Urgent > Routine, then by submission time (BR-05). Target response times per level are set by NBC (open item C-05), shown as configuration, not hard-coded.

**Impact.** W0 BR-01; AD-UC-01 Q2 (urgency part closed); UI conventions labels.

### D-09 BMS reservation behaviour
**Decision.**
- One reservation attempt per submission; timeout 10 s by default (configurable). No answer in time = unavailable.
- The request ID is sent as an idempotency key, so a retry by the user cannot reserve twice.
- If BMS reserves but NBSP fails to save the shipment, NBSP sends a **release reservation** call; if that also fails, the case is logged for manual reconciliation.
- The shortage check before submission uses the synchronised snapshot and is advisory; the BMS reservation result is authoritative.

**Why.** A reservation in BMS without a matching Dispatched request locks real blood that nobody will ship.

**Impact.** W1 FR-01-03 EARS (IF clauses) and L3 FR-01-03-INT description (no change in hours); SD-UC-08 add the compensation note; AD-UC-08 Q2 closed; W5 open questions.

### D-10 Receipt confirmation
**Decision.** Hospital Staff confirm the whole shipment once (BR-03). An optional note can be entered. Units that arrive damaged or missing are then recorded through UC-04 with status Discarded and reason "Damaged on arrival" or "Missing on arrival".

**Why.** Partial receipt would need a dispute flow with NBC. The workaround keeps inventory and usage history correct and costs nothing.

**Impact.** AD-UC-03 Q2 closed; W1 FR-02-01 reason list; AD-UC-03 s3 traces to FR-01-07 (not "FR-01-05 proposed").

### D-11 Shipment visibility
**Decision.** FR-01-04 View shipment details is **Must**. No push notification when a request is Dispatched in release 1: the hospital sees status, units, expiry dates and ETA on S-F01-02. FR-01-04 EARS reads "dispatched", not "approved or dispatched".

**Why.** The W4 justification ("dispatch already sends shipment information to the hospital") is false: AD-UC-08 Q3 decided there is no such message. Without FR-01-04 the hospital cannot see ETA or expiry and has no list from which to confirm receipt (FR-01-05, Must).

**Impact.** W4, W2, W5 (D-25); W1 FR-01-04 EARS and UC-02 wording; AD-UC-08 Q3 and Q5 closed.

---

## 3. Inventory (F-02)

### D-12 Blood product type
**Decision.** Request, unit, lot, usage record, inventory snapshot and forecast all carry **product type**. The list is configurable. Release 1 enables **red blood cells (khối hồng cầu)** only; other products continue by phone. The near-expiry window (W5 Q1) is set per product type. A quantity is counted in units (bags), not millilitres.

**Why.** NBC supplies components, not "blood type" alone, and shelf life differs from days (platelets) to months (frozen plasma). One near-expiry window for all products is meaningless. Adding the field now is almost free; adding it after build means migrating every table. Red cells carry most of the volume and the shortage risk, so they are the right first scope for forecasting.

**Impact.** W0 BR-01, Table 3 (other products = Won't-have for release 1), Table 4 data groups; W1 FR-01-01, FR-02-01, FR-02-03 EARS; W5 Q1; AD-UC-01 Q2.

### D-13 Hospital inventory per lot
**Decision.** Hospital inventory is kept per **lot** = blood group + product type + expiry date (+ unit IDs when the lot came from an NBSP dispatch). Hospital Staff enter usage by quantity; NBSP deducts earliest expiry first (BR-09) for both Used and Discarded. No barcode scanning in release 1.

**Why.** Quantity-only inventory cannot drive expiry warnings or FEFO. Unit-level entry would slow hospital staff and hurt adoption, so the system picks the lots.

**Impact.** AD-UC-04 Q3 closed (BR-09); W0 Table 4 description of "Hospital inventory & usage records".

### D-14 Opening hospital inventory (new FR-02-07)
**Decision.** Add **FR-02-07 Record opening balance and stock adjustment** (actor Hospital Staff, effective priority Should): enter lots with blood group, product, expiry and quantity, with a reason; every entry is kept in history. Fallback if it is cut: the project team loads opening balances with an import script during hospital onboarding (costed in W6 "Other one-time cost").

EARS: *WHEN Hospital Staff records an opening balance or a stock adjustment with blood group, product type, expiry date, quantity and reason, the system SHALL update the hospital lot and append the change to inventory history; IF a field is missing or the adjustment would make a lot negative, the system SHALL change nothing and SHALL show the reason.*

L3: FR-02-07-FE (S, 4 h base, 2.0 person-hours, 400,000 VND); FR-02-07-BE (S, 4 h base, 3.4 person-hours, 1,020,000 VND). FP type EI.

**Why.** On go-live day hospital inventory in NBSP is zero, so FR-02-06 would reject every usage record for blood received before go-live. Hospitals also receive blood from sources other than NBC. Without this, usage data (the forecasting input) is wrong from day one.

**Impact.** W1 (29 L2, 54 L3, 356 base hours); W2; W4; W5; W6; screen S-F02-01 gains an "Opening balance / adjustment" tab (no new screen).

### D-15 Synchronisation behaviour (UC-17)
**Decision.** Interval 15 min by default, configurable. Read-only (BMS is written only by the UC-08 reservation, D-09). Invalid data = negative or non-integer units, unknown blood group or product type. One attempt per interval; the next interval is the retry. No failure notification in release 1, but every screen showing NBC stock displays the sync time and a warning banner when the snapshot is older than two intervals.

**Why.** The banner gives staff the "is this data stale?" answer without building a monitoring function.

**Impact.** AD-UC-17 Q1 to Q5 closed; SD-UC-17 note; UI conventions message "Dữ liệu tồn kho có thể đã cũ" (rule: older than two intervals); FR-02-02-FE scope (no hours change).

---

## 4. Alerts (UC-11)

### D-16 Alert recipients
**Decision.** Below-threshold alerts go to the **Dept and NBC Operations**.

**Why.** The Dept reacts by checking the queue and stock; Operations reacts by planning donor mobilisation (blood drives), which is the only real fix for a low O- stock. The later and more widely adopted decision (usage flow v2.2 of 07/11, SD-UC-11, Context Diagram v4, screen transition) already says both; AD-UC-11 v0.9 and W0 are the outliers.

**Impact.** AD-UC-11 (add Operations lane or note, version v1.0); W0 UC-11 actor; W1 FR-02-04 EARS; use case diagram (add OPS --- UC11, remove "see open point 1").

### D-17 One alert per episode
**Decision.** An alert is created when the stock of a blood group and product **crosses from at-or-above to below** its threshold. It stays **Open** while stock remains below and becomes **Resolved** automatically at the first sync where stock is back at or above. No new alert is created while one is Open. No acknowledgement step and no notification-centre screen in release 1.

**Why.** At a 15-minute sync, "one alert per sync" produces up to 96 alerts a day per blood group; users stop reading them within a week.

**Impact.** AD-UC-11 Q1 and Q3 closed (states Open, Resolved); SD-UC-11 add "if no Open alert"; W1 FR-02-04 EARS; L3 FR-02-04-FE description becomes "alert banner on S-F02-02 and email" (hours unchanged).

### D-18 Release-1 alert scope
**Decision.** Release 1 compares **NBC stock** (from BMS) with thresholds. Thresholds per hospital are Won't-have in release 1 and recorded in W0 Table 3.

**Why.** Hospital-level thresholds need trustworthy hospital inventory, which depends on D-13 and D-14 running for some time. The brief must not promise more than release 1 delivers.

**Impact.** Project brief Goal: reword to "The Center is warned when its own stock of a blood group falls below threshold; warnings on hospital stock follow once hospital inventory data is reliable."

### D-19 Configuration values
**Decision.** Confirmed: alert thresholds, anomaly-rule values, near-expiry windows, verification deadline, forecast cut-off, sync interval and BMS timeout are configuration loaded at deployment and changeable by the NBSP administrator without a code change. No configuration screen or use case in release 1.

**Impact.** W0 Table 3 row already exists (extend the list); usage flow finding 3 and UI conventions OQ-07 closed (the Context Diagram v4 no longer has "configure thresholds").

---

## 5. Notifications

### D-20 One notification pattern
**Decision.** Every notification in NBSP (below-threshold alert, verification request to a hospital, verification response or overdue to the Analyst, draft forecast ready, request Not approved) is delivered as:
1. an **in-app badge** on the relevant menu item and a banner on the target screen; and
2. an **email** with a deep link to the target screen (sign-in first if the session has expired).

**Why.** The screen transition diagram already relies on email links (verification email, alert). One pattern means one L3 implementation reused everywhere instead of a notification centre.

**Impact.** Screen list "What is deliberately not a screen" (channel no longer "to confirm"); usage flow; UI conventions OQ-03 closed; AD-UC-11 s3 and SD-UC-11 text "in-app badge and email".

---

## 6. Forecasting (F-03)

### D-21 Forecast review per item
**Decision.** UC-15 follows W1 FR-03-06 and SD-UC-15: the draft is a batch of items (NBC-wide and per hospital, by blood group, product and horizon) split into Normal and Needs Review. The Analyst approves, adjusts with a reason, or rejects with a reason per Needs Review item, and approves the Normal group in one action. Approved items are published as a new immutable version; rejected or undecided items are not published. Release 1 does not regenerate a rejected item; the reason goes to the Data/ML team outside NBSP.

**Impact.** AD-UC-15 redrawn (v1.0, inside a mermaid block, escapes removed); activity index states.

### D-22 Verification response
**Decision.** UC-14 follows W1 FR-03-04 and SD-UC-14: Hospital Staff confirm, correct or supplement each flagged record; a correction requires a value and a note. A request not answered by the configured deadline becomes Overdue and the Analyst is notified (D-20). FR-03-04 stays Could: the Analyst can phone the hospital and record the outcome with a note.

**Impact.** AD-UC-14 redrawn (v1.0, add Supplement and Overdue, state Responded, inside a mermaid block).

---

## 7. Data model and architecture

### D-23 State catalogue
**Decision.** The table below is the only list of states. Every document uses these spellings; the activity index copies this table.

| Object | States | Transitions |
|---|---|---|
| Blood request | Pending, Dispatched, Received, Not approved | Pending → Dispatched (FR-01-03); Dispatched → Received (FR-01-05); Pending → Not approved (FR-01-09) |
| NBC blood unit (in NBSP) | Available, Reserved | read from BMS; Reserved by FR-01-03 |
| Hospital lot | (no status; quantity only) | changed by FR-01-05, FR-02-01, FR-02-07 |
| Usage record | Used, Discarded | — |
| Demand record | Flagged, Accepted, Excluded, Pending Verification | Flagged → Accepted / Excluded / Pending Verification (FR-03-03); Pending Verification → Accepted / Excluded (FR-03-03, FR-03-08) |
| Verification request | Open, Responded, Overdue | Open → Responded (FR-03-04); Open → Overdue (FR-03-04) |
| Demand period | Open, Finalised | Open → Finalised (FR-03-08) |
| Forecast item | Draft, Approved, Rejected | Draft → Approved / Rejected (FR-03-06) |
| Forecast version | Published | created by FR-03-06; earlier versions kept |
| Alert | Open, Resolved | D-17 |
| User account | Active, Locked | — |

"Đang vận chuyển" (in transit) is a display label for Dispatched, not a state (UI conventions 1.2).

### D-24 Lifelines and architecture
**Decision.** Create `architecture/architecture.md` with these elements, and use exactly these lifeline names in every sequence diagram:

| Lifeline | Kind |
|---|---|
| (actor names from D-01) | actor |
| NBSP Web App | element (browser UI, all actors) |
| NBSP Backend | element (business logic, authorisation, notifications) |
| NBSP Database | element |
| NBSP Scheduler | element (UC-17 sync, UC-14 overdue check, FR-03-08 cut-off, FR-03-05 draft generation) |
| Forecast Model | external: the active deployed model, run by NBSP, trained outside |
| Blood Management Software | external system |

**Why.** Today eight different names describe the same parts ("NBSP Portal", "NBC Portal", "Hospital Blood Mgmt Portal", "NBSP System", "Inventory Service", "Forecast Service"…), and SD-UC-04 even shows a "Model Training Service" that W0 puts out of scope. The scheduler closes activity index finding 2.

**Impact.** SD-UC-01 to SD-UC-17 (rename lifelines; SD-UC-04 remove the training service; SD-UC-04 and SD-UC-05 move the confirmation after the save; SD-UC-07 move the `alt` before the display); W1 cost unchanged.

---

## 8. Scope and priorities

### D-25 Priority changes (W4 v2)

| L2 | Function | W4 v1 | W4 v2 | Rule and justification |
|---|---|---|---|---|
| FR-01-04 | View shipment details | Could | **Must** | R1: without it the hospital cannot see ETA or expiry and has no list to confirm receipt (D-11). |
| FR-01-09 | Record non-approval with reason | Could | **Should** | R2: workaround is a phone call, but requests then stay open forever (D-04). |
| FR-03-01 | Log scheduled or periodic demand | Should | **Could** | R3: the first forecast runs on usage and dispatch history (W4 v1 already says so); scheduled demand improves it later. Frees Should budget. |
| FR-02-07 | Opening balance and stock adjustment (new) | — | **Should** | R2: workaround is an onboarding import script by the team (D-14). |

Justifications rewritten without a dependency on a Should item:
- FR-02-03 (Could): *the Dept already sees expiry dates in the Blood Management Software.*
- FR-02-04 (Could): *the Dept already sees NBC stock in the Blood Management Software; the alert saves checking time.*
- FR-02-06 (Should): *hospital staff check quantities before saving; the database also refuses a negative lot quantity, so inventory cannot go below zero.*

Effect on the baseline (person-hours and cost from W2 rates; to be recalculated in the workbook):

| Tier | v1 hours | v1 share | v2 hours | v2 share | v2 cost (VND) |
|---|---|---|---|---|---|
| Must | 156.8 | 58.0% | 162.2 | 58.8% | 45.160.000 |
| Should | 53.4 | 19.7% | 55.4 | 20.1% | 14.920.000 |
| Could | 60.2 | 22.3% | 58.2 | 21.1% | 16.160.000 |
| **Total** | 270.4 | | **275.8** | | **76.240.000** |

| W5 scenario | v1 | v2 |
|---|---|---|
| Pessimistic: Must only | 156.8 h · 43.740.000 | 162.2 h · 45.160.000 |
| Base: Must + Should | 210.2 h · 58.160.000 | 217.6 h · 60.080.000 |
| Optimistic: full scope | 270.4 h · 74.820.000 | 275.8 h · 76.240.000 |

Full scope stays under the 300 person-hour team capacity. W5 tasks.md seed: add FR-01-04-FE and FR-01-04-BE (32 Must L3 items). W6 must be recalculated from the new scenario costs, and its missing "Section 1.6" (benefit derivation) must be added before submission.

---

## 9. Open items for the client (defaults applied until answered)

| # | Question | Blocking? | Default applied | Decision |
|---|---|---|---|---|
| C-01 | Near-expiry window per product type | No | Configurable per product (D-12) | W5 Q1 |
| C-02 | Verification response deadline | No | Configurable | W5 Q2 |
| C-03 | Forecast cut-off schedule | Yes | Configurable cycle cut-off | W5 Q3 |
| C-04 | Approved anomaly rules and values | Yes | Configurable rule engine (Missing Data, Invalid Value, Spike, Inconsistency, Duplicate, Late Entry) | W5 Q4 |
| C-05 | Target response time per urgency level | No | Shown as configuration, no SLA enforcement | D-08 |
| C-06 | Threshold value per blood group (red cells) | No | Loaded at deployment | D-19 |
| C-07 | Sync interval and BMS timeout | No | 15 min, 10 s | D-09, D-15 |
| C-08 | Actual transfusion-patient counts for the rule "zero patients but high usage" | No | Rule disabled until a data source is confirmed | AD-UC-13 Q5 |

Add C-05 to C-08 to the W5 open-question table.

---

## 10. Documentation housekeeping (no approval needed)

- Remove source notes that point to chat histories or screenshots (SD-UC-11, SD-UC-12, SD-UC-13, AD-UC-14, AD-UC-15).
- Fix broken links: `context/cvca.md` (move and rename the root file `cvca`), `function-list/w6-cash-flow.md` → `w6-cashflow.md`, `usage-flow.md` → `usage-flow-total.md`, `architecture/architecture.md` (create, D-24).
- Activity index: close findings 1, 3 and 5 (already fixed); update the Priority column from W4 v2; list only diagrams that exist, or mark AD-UC-06, 09, 12, 16 "not needed" with the reason used in the usage flow.
- SD-UC-09 and SD-UC-10 headers "UC-XX" → UC-09, UC-10; SD-UC-10 FRs → FR-02-03 only.
- Usage flow: renumber Hospital Staff flows 1 to 4; UC-05 invalid data traces to FR-03-01 (not FR-03-08).
- AD-UC-11 screen S-F02-04 → S-F02-02.
- W2: state the tolerance used for the ±% variance between bottom-up and function-point totals.
- Project brief: fill roles and owned features for the five members; align with W0 owners.
- README: one paragraph and a link list to the documents in reading order.
