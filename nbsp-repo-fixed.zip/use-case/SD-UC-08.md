# Sequence Diagram: SD-UC-08 Review and process blood request

| Field | Value |
|---|---|
| Use case | UC-08 Review and process blood request |
| Version | v1 |
| FRs | FR-01-03, FR-01-08, FR-01-09 |

```mermaid
sequenceDiagram
  autonumber
  actor N as NBC Blood Storage and Distribution Department
  participant P as NBSP Web App
  participant S as NBSP Backend
  participant DB as NBSP Database
  participant B as Blood Management Software
  N->>P: Review pending blood request
  activate P
  P->>S: Get request details and available blood units
  activate S
  S->>DB: Query request status and stock snapshot
  activate DB
  DB-->>S: Request details and stock availability
  deactivate DB
  S-->>P: Return request details and available units (pre-selected earliest expiry first, BR-09)
  deactivate S
  P-->>N: Display request and available blood units
  alt Dept declines request (FR-01-09)
    N->>P: Choose Not approved and a reason
    P->>S: Submit Not approved and reason (FR-01-09)
    activate S
    S->>DB: Set request to Not approved and store the reason
    activate DB
    DB-->>S: Decision recorded
    deactivate DB
    S-->>P: Return non-approval confirmation
    deactivate S
    P-->>N: Display non-approval result
  else Dept approves request (FR-01-03)
    N->>P: Select units, enter ETA and confirm dispatch
    P->>S: Submit approval, selected units and ETA
    activate S
    S->>DB: Revalidate request status and stock availability
    activate DB
    DB-->>S: Validation result
    deactivate DB
    alt Request invalid or no longer Pending
      S-->>P: Block dispatch and return validation reason
      P-->>N: Display invalid-request error
    else Insufficient eligible units (FR-01-08)
      S-->>P: Block dispatch and report stock shortage
      P-->>N: Display shortage reason
    else Request valid and stock sufficient
      S->>B: Reserve selected eligible blood units
      activate B
      alt Reservation failed (FR-01-08)
        B-->>S: Units unavailable for reservation
        S-->>P: Block dispatch and report reservation failure
        P-->>N: Display shortage or reservation conflict
      else Reservation successful (FR-01-03)
        B-->>S: Confirm reserved units and expiry dates
        S->>DB: Save shipment, ETA and status as Dispatched
        Note right of S: If this save fails, S asks B to release the reservation (D-09)
        activate DB
        DB-->>S: Shipment and status saved
        deactivate DB
        S-->>P: Return dispatch confirmation
        P-->>N: Display dispatch confirmation
      end
      deactivate B
    end
    deactivate S
  end
  deactivate P
```

